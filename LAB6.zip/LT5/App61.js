import React, { useState } from 'react';
import { StyleSheet, Text, View, Button } from 'react-native';
import Store from './Store';
import { Provider } from 'react-redux';
import ProductList from './ProductList';
import Cart from './Cart';
import ModalCart from './Modalcart'

const App61 = () => {
    const [isCartVisible, setCartVisible] = useState(false);

    const products = [
        { id: 1, name: "P1" },
        { id: 2, name: "P2" },
        { id: 3, name: "P3" },
    ];

    return (
        <Provider store={Store}>
            <View style={{width:'50%',height:'100%',alignSelf:'center'}}>
                <ProductList products={products} />
                <Button style={{marginTop:20}} title="Show Cart" onPress={() => setCartVisible(true)} />
                <ModalCart isVisible={isCartVisible} onClose={() => setCartVisible(false)} />
            </View>
        </Provider>
    );
};

export default App61;

const styles = StyleSheet.create({});
