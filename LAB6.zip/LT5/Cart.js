import { Button, StyleSheet, Text, View } from 'react-native'
import { useDispatch, useSelector } from 'react-redux'
import { removeItem } from './Action'
import React from 'react'

const Cart = () => {
  const cartItems = useSelector(state => state.cart.items);
  const dispatch = useDispatch();
  return (
    <View>
      {
        cartItems.map(item => (
          <View key={item.id}>
            <Text>{item.name} - {item.quantity}</Text>
            <Button title='Xoa khoi gio hang'
              onPress={() => dispatch(removeItem(item))}
            />
          </View>
        ))

      }
    </View>
  )
}

export default Cart

const styles = StyleSheet.create({})