import React from 'react';
import { Modal, Text, View, Button } from 'react-native';
import { useSelector } from 'react-redux';
import Cart from './Cart';

const ModalCart = ({ isVisible, onClose }) => {
    const cartItems = useSelector(state => state.cart.items);

    return (
        <Modal
            visible={isVisible}
            animationType="slide"
            transparent={true}
        >
            <View style={{ flex:1, justifyContent: 'center', alignItems: 'center', backgroundColor: 'rgba(0, 0, 0, 0.5)' }}>
                <View style={{ backgroundColor: 'white', padding: 20 }}>
                    <Text style={{ fontSize: 18, marginBottom: 10 }}>Cart</Text>
                   <Cart/>
                    <Button title="Close" onPress={onClose} />
                </View>
            </View>
        </Modal>
    );
};

export default ModalCart;
