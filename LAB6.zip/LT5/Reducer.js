import { createReducer } from "@reduxjs/toolkit";
import {addItem,removeItem} from "./Action"

//khởi tạo trạng thái
const initState = {items:[]};
//tao reducer (khi click se goi den)
const cardReducer = createReducer(initState,builder =>{
    builder
    .addCase(addItem,(state,action)=>{
        //them so luong khi gio hang da ton tai sp trong gio hang
        const tontaiItemIndex = state.items.findIndex(
            items=>items.id==action.payload.id
        );
        //khi chua co san pham torng gio hang
        if(tontaiItemIndex !== -1){
            state.items[tontaiItemIndex].quantity++;

        }else{
            state.items.push({...action.payload,quantity:1})
        }
    })
    .addCase(removeItem,(state,action)=>{
        const tontaiItemIndex = state.items.findIndex(
            item => item.id ===action.payload.id
        );
        if(tontaiItemIndex !== -1){
            state.items[tontaiItemIndex].quantity--;
        }
        //so luong bang 0 thi xoa khoi gio hang
        if(state.items[tontaiItemIndex].quantity ===0){
            state.items.splice(tontaiItemIndex,1);
        }
    });
});
export default cardReducer;